#!/usr/bin/env bash
set -euo pipefail

INSTALL_DIR="/opt/assistantservice"
SERVICE_NAME="assistantservice"
SERVICE_FILE="/etc/systemd/system/${SERVICE_NAME}.service"
SECRETS_DIR="/etc/systemd/system/${SERVICE_NAME}.service.d"
SECRETS_FILE="${SECRETS_DIR}/secrets.conf"
CONFIG_FILE="${INSTALL_DIR}/appsettings.Production.json"

# Defaults (mirror Windows installer)
D_DS_PROXY="http://ai2.datascienceai.nsf/llm"
D_QDRANT_CONN="localhost:6334"
D_QDRANT_EMBED_SIZE="1024"
D_PORT="7002"
D_AZURE_ENDPOINT="https://teodo-m91b9nxu-eastus2.cognitiveservices.azure.com"
D_AZURE_API_VERSION="2024-12-01-preview"
D_EMBEDDING_MODEL="mxbai-embed-large-v1"
D_MODELS_CSV="qwen, llama-3.3-70b-instruct-awq, gpt-4o-dsai, openai.gpt-oss-120b-1:0"
D_MINIO_ENDPOINT="localhost:9000"
D_MINIO_BUCKET="chat-uploads"
D_MINIO_SSL="false"
D_MINIO_ACCESS="minioadmin"
D_MINIO_SECRET="minioadmin"
QDRANT_VERSION="1.16.3"

die()        { echo "ERROR: $*" >&2; exit 1; }
section()    { echo; echo "=== $* ==="; }
json_esc()   { printf '%s' "$1" | sed 's/\\/\\\\/g; s/"/\\"/g'; }

ask() {
    local label="$1" default="$2"
    local value
    read -rp "  ${label} [${default}]: " value
    printf '%s' "${value:-$default}"
}

ask_secret() {
    local label="$1" default="$2"
    local value
    read -rsp "  ${label} [${default:+(set)}${default:-(none)}]: " value
    echo >&2
    printf '%s' "${value:-$default}"
}

csv_to_json_array() {
    local csv="$1" result="[" first=true item
    while IFS= read -rd ',' item || { item="$item"; [ -n "$item" ]; }; do
        item=$(printf '%s' "$item" | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')
        [ -z "$item" ] && continue
        [ "$first" = "true" ] && first=false || result+=", "
        result+="\"$(json_esc "$item")\""
    done <<< "${csv},"
    printf '%s' "${result}]"
}

write_config() {
    printf '{\n'
    printf '  "ConnectionStrings": {\n'
    printf '    "DatascienceProxy": "%s",\n'     "$(json_esc "$DS_PROXY")"
    printf '    "QdrantConnection": "%s",\n'     "$(json_esc "$QDRANT_CONN")"
    printf '    "QdrantEmbeddingSize": "%s"\n'   "$(json_esc "$QDRANT_EMBED_SIZE")"
    printf '  },\n'
    printf '  "DataScienceEmbeddingModel": "%s",\n' "$(json_esc "$EMBEDDING_MODEL")"
    printf '  "DataScienceModels": { "Models": %s },\n' "$(csv_to_json_array "$MODELS_CSV")"
    printf '  "Web": { "Port": %s },\n'          "$PORT"
    printf '  "Minio": {\n'
    printf '    "Endpoint": "%s",\n'             "$(json_esc "$MINIO_ENDPOINT")"
    printf '    "Bucket": "%s",\n'               "$(json_esc "$MINIO_BUCKET")"
    printf '    "WithSSL": %s\n'                 "$MINIO_SSL"
    printf '  },\n'
    printf '  "AzureOpenAI": {\n'
    printf '    "Endpoint": "%s",\n'             "$(json_esc "$AZURE_ENDPOINT")"
    printf '    "ApiVersion": "%s"\n'            "$(json_esc "$AZURE_API_VERSION")"
    printf '  }\n'
    printf '}\n'
}

write_secrets() {
    printf '[Service]\n'
    printf 'Environment="AIProxyKey=%s"\n'                    "$AI_PROXY_KEY"
    printf 'Environment="ConnectionStrings__QdrantKey=%s"\n'  "$QDRANT_KEY"
    printf 'Environment="AzureOpenAI__ApiKey=%s"\n'           "$AZURE_API_KEY"
    printf 'Environment="Minio__AccessKey=%s"\n'              "$MINIO_ACCESS"
    printf 'Environment="Minio__SecretKey=%s"\n'              "$MINIO_SECRET"
}

fetch() {
    local url="$1" dest="$2"
    if command -v curl &>/dev/null; then
        curl -fsSL "$url" -o "$dest"
    elif command -v wget &>/dev/null; then
        wget -q "$url" -O "$dest"
    else
        die "Neither curl nor wget found. Install one and retry."
    fi
}

install_qdrant() {
    local qdrant_dir="/opt/qdrant"
    local data_dir="/var/lib/qdrant"

    if [ -f "$qdrant_dir/qdrant" ]; then
        echo "  Qdrant already present at $qdrant_dir — skipping download."
    else
        echo "  Downloading Qdrant ${QDRANT_VERSION}..."
        local url="https://github.com/qdrant/qdrant/releases/download/v${QDRANT_VERSION}/qdrant-x86_64-unknown-linux-musl.tar.gz"
        fetch "$url" /tmp/qdrant.tar.gz
        mkdir -p "$qdrant_dir"
        tar -xzf /tmp/qdrant.tar.gz -C "$qdrant_dir"
        rm -f /tmp/qdrant.tar.gz
        chmod +x "$qdrant_dir/qdrant"
        echo "  Qdrant binary installed: $qdrant_dir/qdrant"
    fi

    mkdir -p "$data_dir/storage" "$data_dir/snapshots"

    local api_key_line=""
    [ -n "${QDRANT_KEY:-}" ] && api_key_line=$'\n'"  api_key: \"$(json_esc "$QDRANT_KEY")\""

    cat > "$qdrant_dir/config.yaml" <<EOF
service:
  host: 127.0.0.1
  http_port: 6333
  grpc_port: 6334${api_key_line}

storage:
  storage_path: ${data_dir}/storage
  snapshots_path: ${data_dir}/snapshots
EOF

    cat > /etc/systemd/system/qdrant.service <<EOF
[Unit]
Description=Qdrant Vector Database
After=network.target

[Service]
Type=simple
WorkingDirectory=${qdrant_dir}
ExecStart=${qdrant_dir}/qdrant --config-path ${qdrant_dir}/config.yaml
Restart=on-failure
RestartSec=5
SyslogIdentifier=qdrant

[Install]
WantedBy=multi-user.target
EOF

    systemctl daemon-reload
    systemctl enable qdrant
    systemctl start qdrant
    echo "  Qdrant enabled and started (HTTP :6333, gRPC :6334)."
}

install_minio() {
    if [ -f "/usr/local/bin/minio" ]; then
        echo "  MinIO already present — skipping download."
    else
        echo "  Downloading MinIO..."
        fetch "https://dl.min.io/server/minio/release/linux-amd64/minio" /usr/local/bin/minio
        chmod +x /usr/local/bin/minio
        echo "  MinIO binary installed: /usr/local/bin/minio"
    fi

    mkdir -p /var/minio/data

    cat > /etc/systemd/system/minio.service <<EOF
[Unit]
Description=MinIO Object Storage
After=network.target

[Service]
Type=simple
ExecStart=/usr/local/bin/minio server /var/minio/data --address :9000 --console-address :9001
Environment="MINIO_ROOT_USER=$(json_esc "${MINIO_ACCESS:-minioadmin}")"
Environment="MINIO_ROOT_PASSWORD=$(json_esc "${MINIO_SECRET:-minioadmin}")"
Restart=on-failure
RestartSec=5
SyslogIdentifier=minio

[Install]
WantedBy=multi-user.target
EOF
    chmod 600 /etc/systemd/system/minio.service

    systemctl daemon-reload
    systemctl enable minio
    systemctl start minio
    echo "  MinIO enabled and started (S3 :9000, console :9001)."
}

# ---- Require root ----
[ "$(id -u)" -eq 0 ] || die "Run as root: sudo $0 $*"

# ---- Find tarball ----
TARBALL="${1:-}"
if [ -z "$TARBALL" ]; then
    TARBALL=$(ls assistantservice-linux-x64-*.tar.gz 2>/dev/null | sort -V | tail -1 || true)
fi
[ -n "$TARBALL" ] || die "No tarball specified and none found in current directory."
[ -f "$TARBALL" ] || die "File not found: $TARBALL"
echo "Installing from: $TARBALL"

# ---- Detect existing install ----
CONFIG_EXISTS=false; [ -f "$CONFIG_FILE" ] && CONFIG_EXISTS=true
SECRETS_EXIST=false; [ -f "$SECRETS_FILE" ] && SECRETS_EXIST=true

# ---- Stop service ----
if systemctl is-active --quiet "$SERVICE_NAME" 2>/dev/null; then
    echo "Stopping existing service..."
    systemctl stop "$SERVICE_NAME"
fi

# ---- Extract + permissions ----
echo "Extracting to $INSTALL_DIR..."
mkdir -p "$INSTALL_DIR/logs"
tar -xzf "$TARBALL" -C "$INSTALL_DIR"
chmod +x "$INSTALL_DIR/AssistantService"
chown -R root:root "$INSTALL_DIR"
chmod 750 "$INSTALL_DIR"
chmod 640 "$INSTALL_DIR"/*.json 2>/dev/null || true
chmod 640 "$INSTALL_DIR"/*.service 2>/dev/null || true

# ---- Install systemd unit ----
if [ -f "$INSTALL_DIR/assistantservice.service" ]; then
    cp "$INSTALL_DIR/assistantservice.service" "$SERVICE_FILE"
    echo "Systemd unit installed: $SERVICE_FILE"
fi

# ---- Optional dependencies ----
section "Optional dependencies"
echo "  These will be downloaded and installed as systemd services."
echo
INSTALL_QDRANT=false
read -rp "  Install Qdrant ${QDRANT_VERSION} (vector database)? [Y/n]: " ans
[[ "$ans" =~ ^[Nn] ]] || INSTALL_QDRANT=true

INSTALL_MINIO=false
read -rp "  Install MinIO (object storage for file uploads)? [Y/n]: " ans
[[ "$ans" =~ ^[Nn] ]] || INSTALL_MINIO=true

# ---- Page 1+2: Non-secret config ----
WRITE_CONFIG=true
if [ "$CONFIG_EXISTS" = "true" ]; then
    section "Existing configuration found"
    echo "  $CONFIG_FILE"
    read -rp "  Overwrite existing configuration? [y/N]: " ans
    [[ "$ans" =~ ^[Yy] ]] || WRITE_CONFIG=false
fi

if [ "$WRITE_CONFIG" = "true" ]; then
    section "Connection settings (1/2)"
    DS_PROXY=$(ask       "DataScience proxy URL"         "$D_DS_PROXY")
    QDRANT_CONN=$(ask    "Qdrant connection (host:port)" "$D_QDRANT_CONN")
    QDRANT_EMBED_SIZE=$(ask "Qdrant embedding size"     "$D_QDRANT_EMBED_SIZE")
    PORT=$(ask           "Web port"                      "$D_PORT")
    AZURE_ENDPOINT=$(ask "Azure OpenAI endpoint URL"    "$D_AZURE_ENDPOINT")
    AZURE_API_VERSION=$(ask "Azure OpenAI API version"  "$D_AZURE_API_VERSION")

    section "Models and storage (2/2)"
    EMBEDDING_MODEL=$(ask "Embedding model"                     "$D_EMBEDDING_MODEL")
    MODELS_CSV=$(ask      "Available models (comma-separated)"  "$D_MODELS_CSV")
    MINIO_ENDPOINT=$(ask  "MinIO endpoint (host:port)"          "$D_MINIO_ENDPOINT")
    MINIO_BUCKET=$(ask    "MinIO bucket name"                   "$D_MINIO_BUCKET")
    MINIO_SSL=$(ask       "Use SSL (true/false)"                "$D_MINIO_SSL")

    write_config > "$CONFIG_FILE"
    chmod 640 "$CONFIG_FILE"
    chown root:root "$CONFIG_FILE"
    echo "Config written: $CONFIG_FILE"
fi

# ---- Page 3+4: Credentials ----
WRITE_SECRETS=true
if [ "$SECRETS_EXIST" = "true" ]; then
    section "Existing credentials found"
    echo "  $SECRETS_FILE"
    read -rp "  Overwrite existing credentials? [y/N]: " ans
    [[ "$ans" =~ ^[Yy] ]] || WRITE_SECRETS=false
fi

if [ "$WRITE_SECRETS" = "true" ]; then
    section "AI Proxy + Qdrant (3/4)"
    AI_PROXY_KEY=$(ask_secret "AI proxy key"  "")
    QDRANT_KEY=$(ask_secret   "Qdrant API key" "")

    section "Azure OpenAI (3/4)"
    AZURE_API_KEY=$(ask_secret "Azure OpenAI API key" "")

    section "MinIO / S3 credentials (4/4)"
    MINIO_ACCESS=$(ask        "Access key"  "$D_MINIO_ACCESS")
    MINIO_SECRET=$(ask_secret "Secret key"  "$D_MINIO_SECRET")

    mkdir -p "$SECRETS_DIR"
    write_secrets > "$SECRETS_FILE"
    chmod 600 "$SECRETS_FILE"
    chown root:root "$SECRETS_FILE"
    echo "Credentials written (root-only): $SECRETS_FILE"
fi

# ---- Install optional dependencies ----
[ "$INSTALL_QDRANT" = "true" ] && { section "Installing Qdrant";  install_qdrant; }
[ "$INSTALL_MINIO"  = "true" ] && { section "Installing MinIO";   install_minio;  }

# ---- Enable + start ----
systemctl daemon-reload
systemctl enable "$SERVICE_NAME"
systemctl start  "$SERVICE_NAME"

PORT_DISPLAY=$(grep -oP '"Port":\s*\K[0-9]+' "$CONFIG_FILE" 2>/dev/null || echo "7002")

echo
echo "Installation complete."
echo "  Status : systemctl status $SERVICE_NAME"
echo "  Logs   : journalctl -u $SERVICE_NAME -f"
echo "  Web UI : http://localhost:${PORT_DISPLAY}/chat/index.html"
